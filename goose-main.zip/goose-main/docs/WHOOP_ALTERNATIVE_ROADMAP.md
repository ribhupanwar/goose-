# Goose: WHOOP-Alternative Product Roadmap

This roadmap is based on the current SwiftUI + Rust architecture. The app already has substantial foundations:
BLE ingestion for WHOOP 5.0, a local Rust scoring bridge, HealthKit import, sleep/recovery/strain/stress/cardio-load surfaces, activity recording, Coach, and raw-data diagnostics.

The current README correctly labels the project an alpha proof of concept. Do not market scores as WHOOP-equivalent until the underlying inputs, validation, and history are reliable.

## Product direction

Build a local-first training and recovery platform that combines:
- WHOOP band data when a supported band is connected.
- Apple Health / Apple Watch data with clear source attribution.
- Workout sessions and running-specific training analysis.
- Transparent recovery, sleep, strain, stress, and coaching insights.

The app must never silently substitute fabricated values for missing sensor data.

## Priority 0 — Trust and data reliability

1. **One source-of-truth data layer**
   - Normalize every sample with metric, value, unit, timestamp, source, quality, and confidence.
   - Deduplicate HealthKit and BLE samples without double-counting.
   - Show freshness and provenance on every important metric.
2. **Permission and sync health**
   - Add a HealthKit permission diagnostic that distinguishes unavailable, not requested, denied, and authorized states.
   - Explain that HealthKit read permissions are privacy-protected and cannot be reliably inferred from an empty query alone.
   - Add last successful BLE sync, last HealthKit import, queued samples, and failed imports to a single sync status surface.
3. **Real score inputs**
   - Keep Sleep, Recovery, Strain, Stress, and Energy scores unavailable when required inputs are missing.
   - Persist daily score inputs and outputs so historical scores do not change unexpectedly after a refresh.
   - Add confidence and algorithm version to every score record.

## Priority 1 — WHOOP-style daily experience

1. Home should lead with device/sync status, then Sleep / Recovery / Strain, followed by Stress / Energy and today's training load.
2. Recovery should explain HRV, resting HR, sleep, respiratory rate, and temperature contributions instead of showing only a number.
3. Sleep should include duration, consistency, stages, sleep debt, sleep need, and a readable sleep timeline.
4. Strain should include daily cardiovascular load, workout contribution, and non-workout activity where measured.
5. Stress should separate exercise-related stress from non-activity stress.
6. Add 7-day and 30-day trends with baseline comparisons, not just isolated daily scores.

## Priority 2 — Running-first differentiation

1. Build a running dashboard: weekly distance, time, pace, elevation, frequency, long run, and intensity distribution.
2. Track HR zones and time-in-zone from actual workout samples; label estimates clearly.
3. Add aerobic load / acute-vs-chronic trend only after enough valid history exists.
4. Track VO2 max, resting HR, HRV, lactate-threshold pace/HR, and race predictions only when the source provides valid observations.
5. For each run, show pace stability, HR drift, splits, cadence, elevation, and recovery cost where samples exist.
6. Add training suggestions that respect recovery, recent load, pain/injury notes, and upcoming race goals. Avoid medical diagnosis.

## Priority 3 — Coach and personalization

1. Generate a daily recommendation from actual local metrics and training history.
2. Explain *why* the recommendation was made and identify missing/conflicting inputs.
3. Offer post-run analysis and weekly review.
4. Let the user add subjective recovery, soreness, mood, and perceived exertion; keep subjective and sensor data separate.
5. Make all AI features opt-in, with a clear summary of what data is sent off-device.

## Priority 4 — Validation and release quality

- Add deterministic tests for score calculations, time zones, sleep windows, deduplication, and missing/stale data.
- Compare score outputs against a labeled set of real user-days; do not tune against a single day.
- Add migration tests and database backup/export checks.
- Add UI tests for disconnected, stale, permission-denied, partial-data, and fully-populated states.
- Profile BLE ingestion, SQLite writes, and chart rendering on a physical iPhone.
- Publish a metric dictionary documenting units, source priority, confidence, and known limitations.

## Current hard limitation

The current repository documents WHOOP 5.0 as the only supported band generation. That means it is not yet a device-independent WHOOP replacement. The practical near-term product is a WHOOP + Apple Health companion with better running analysis; true independence requires reliable Apple Watch/HealthKit capture and validated scoring that does not depend on WHOOP-only packet streams.
